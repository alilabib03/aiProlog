above(lettuce, patty).
above(cheese, lettuce).
above(pickles, tomato).


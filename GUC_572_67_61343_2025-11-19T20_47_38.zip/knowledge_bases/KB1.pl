above(tomato, lettuce).
above(tomato, patty).
above(pickles, cheese).
above(cheese, tomato).